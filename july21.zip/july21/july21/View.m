//
//  View.m
//  july21
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "View.h"

@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor blackColor];
		
		//Create the leave in the upper left corner of this View.
		frame = CGRectMake(20, 20, 120, 120);
        star1 = [[UIImageView alloc] initWithFrame: frame];
        [star1 setImage:[UIImage imageNamed: @"star.png"]];
        star1.opaque = YES;
		star1.backgroundColor = [UIColor clearColor];
		[self addSubview: star1];
        
        frame = CGRectMake(220, 80, 100, 100);
       star2 = [[UIImageView alloc] initWithFrame: frame];
        [star2 setImage:[UIImage imageNamed: @"star.png"]];
        star2.opaque = YES;
		star2.backgroundColor = [UIColor clearColor];
		[self addSubview:star2];
        
        frame = CGRectMake(50, 180, 120, 120);
        star3 = [[UIImageView alloc] initWithFrame: frame];
        [star3 setImage:[UIImage imageNamed: @"star.png"]];
        star3.opaque = YES;
		star3.backgroundColor = [UIColor clearColor];
		[self addSubview: star3];
        
        frame = CGRectMake(200, 200, 140, 140);
       star4 = [[UIImageView alloc] initWithFrame: frame];
        [star4 setImage:[UIImage imageNamed: @"star.png"]];
       star4.opaque = YES;
		star4.backgroundColor = [UIColor clearColor];
		[self addSubview: star4];
        
        frame = CGRectMake(10, 300, 120, 120);
        star5 = [[UIImageView alloc] initWithFrame: frame];
        [star5 setImage:[UIImage imageNamed: @"star.png"]];
        star5.opaque = YES;
		star5.backgroundColor = [UIColor clearColor];
		[self addSubview: star5];
        
        frame = CGRectMake(120, 330, 140, 140);
        star6 = [[UIImageView alloc] initWithFrame: frame];
        [star6 setImage:[UIImage imageNamed: @"star.png"]];
        star6.opaque = YES;
		star6.backgroundColor = [UIColor clearColor];
		[self addSubview: star6];
        
        rotation = 1;
        cntr = 0;
        pos = 1;
		//Ball initially moves to lower right.
		dx = 3;
		dy = 3;
    }
    return self;
}

- (void) bounce {	
	//Where the ball would be if its horizontal motion were allowed
	//to continue for one more move.
	CGRect horizontal = star1.frame;
	horizontal.origin.x += dx;
    
    horizontal = star2.frame;
	horizontal.origin.x += dx;
    
    horizontal = star3.frame;
	horizontal.origin.x += dx;
    
    horizontal = star4.frame;
	horizontal.origin.x += dx;
    
    horizontal = star5.frame;
	horizontal.origin.x += dx;
    
    horizontal = star6.frame;
	horizontal.origin.x += dx;
    
	//Where the ball would be if its vertical motion were allowed
	//to continue for one more move.
	CGRect vertical = star1.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = star2.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = star3.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = star4.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = star5.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = star6.frame;
	vertical.origin.y += (dy * pos);
    
    
	//Ball must remain inside self.bounds.
	if (!CGRectEqualToRect(horizontal, CGRectIntersection(horizontal, self.bounds))) {
		//Ball will bounce off left or right edge of View.
		dx = -dx;
	}
    
	if (!CGRectEqualToRect(vertical, CGRectIntersection(vertical, self.bounds))) {
		//Ball will bounce off top or bottom edge of View.
		dy = -dy;
	}
	
}

- (void) move: (CADisplayLink *) displayLink {
    
    //NSLog(@"leave.center.x: %f", leave.center.x);
    //NSLog(@"leave.center.y: %f", leave.center.y);
	star1.center = CGPointMake(star1.center.x + dx, star1.center.y + (dy * pos));
    star2.center = CGPointMake(star2.center.x + dx, star2.center.y + (dy * pos));
    star3.center = CGPointMake(star3.center.x + dx, star3.center.y + (dy * pos));
    star4.center = CGPointMake(star4.center.x + dx, star4.center.y + (dy * pos));
    star5.center = CGPointMake(star5.center.x + dx, star5.center.y + (dy * pos));
    star6.center = CGPointMake(star6.center.x + dx, star6.center.y + (dy * pos));
    cntr += 1;
    //NSLog(@"counter: %f", counter);
    //if (counter >= 5) {
    //    dx = -dx;
    //}
    
    if (cntr == 5) {
        cntr = 0;
        star1.transform = CGAffineTransformMakeRotation(3.14159265*rotation); //rotation in radians
        star2.transform = CGAffineTransformMakeRotation(3.14159265*(rotation/2)); //rotation in radians
        star3.transform = CGAffineTransformMakeRotation(3.14159265*(rotation/2)); //rotation in radians
        star4.transform = CGAffineTransformMakeRotation(3.14159265*rotation); //rotation in radians
        star5.transform = CGAffineTransformMakeRotation(3.14159265*(rotation/2)); //rotation in radians
        star6.transform = CGAffineTransformMakeRotation(3.14159265*rotation); //rotation in radians

        rotation += .5;
        if (rotation >= 2) {
            rotation = .5;
            if (pos < 0) {
                pos = 1;
            }
            else {
                pos = -1;
            }
        }
        //NSLog(@"rotation: %f",rotation);
    }
	[self bounce];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)dealloc
{
    [super dealloc];
}


@end
