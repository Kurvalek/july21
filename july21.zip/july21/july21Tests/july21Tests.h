//
//  july21Tests.h
//  july21Tests
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface july21Tests : SenTestCase

@end
