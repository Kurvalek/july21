//
//  View.h
//  july21
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View : UIView {
    UIImageView *star1;
    UIImageView *star2;
    UIImageView *star3;
    UIImageView *star4;
    UIImageView *star5;
    UIImageView *star6;
	CGFloat dx, dy;	//direction and speed of ball's motion
    CGFloat rotation; // for rotating object
    CGFloat cntr;
    CGFloat pos;
}

- (void) move: (CADisplayLink *) displayLink;

@end
