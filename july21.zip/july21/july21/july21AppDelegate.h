//
//  july21AppDelegate.h
//  july21
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

@interface july21AppDelegate : NSObject <UIApplicationDelegate> {
ViewController *viewController;
UIWindow *_window;
}
@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
