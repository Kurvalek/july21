//
//  ViewController.h
//  july21
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ViewController : UIViewController
{
    CADisplayLink *displayLink;
}

@end
